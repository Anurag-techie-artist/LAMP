package org.fog.lamp.baselines;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.fog.application.AppModule;
import org.fog.application.Application;
import org.fog.entities.FogDevice;
import org.fog.lamp.application.HealthcareBSNApplication;
import org.fog.placement.ModuleMapping;
import org.fog.placement.ModulePlacement;
import org.fog.placement.ModulePlacementMapping;

/**
 * Isolated LBMP_PURE Implementation (Phase 3.5).
 *
 * Governing Contract: PHASE_3_4_LBMP_DESIGN_SPECIFICATION.md (Rev. 2)
 * Primary Baseline Reference: M. Taneja & A. Davy (IFIP/IEEE IM 2017), Algorithms 1-3, Eqs. 1-12.
 * Primary Target Reference: Z. Rezazadeh, M. Rezaei & M. Nickray (IEEE KBEI 2019).
 *
 * Approved Design Decisions Implemented:
 *  - D-3.4-01: LBMP_PURE only (zero locality/affinity logic in placement decisions).
 *  - D-3.4-02: LBMP_AFFINITY deferred; historical SAMP and SA_SYNTHETIC excluded.
 *  - D-3.4-03: Option A BW — Node BW = Host.getBw(), Module BW = AppModule.getBw().
 *              Explicitly documented as a CloudSim VM-layer bandwidth approximation,
 *              NOT an exact reproduction of Taneja & Davy's Mbps model.
 *  - D-3.4-04: Reset low = 0 after every dynamic node re-sort (necessary multi-app
 *              adaptation to published Algorithm 1 Line 11 `low = i + 1`).
 *  - D-3.4-05: Design C1 — Cloud remains inside candidate nodes[] (N = N_F U N_C).
 *  - D-3.4-06: Strict package isolation in org.fog.lamp.baselines.
 *  - D-3.4-07: Fixed-module accounting convention: Cloud_Storage RAM (10 MB) and
 *              Host BW (1,000) are pre-reserved in the LBMP analytical resource ledger.
 *              Its CPU is intentionally excluded to preserve comparability with the
 *              existing LAMP/EWMP placement convention. Consequently, the LBMP ledger
 *              is not a complete mirror of CloudSim's resource consumption.
 *  - D-3.4-08: Strict separation of normal Cloud selection vs. unconditional Cloud fallback;
 *              explicit cloudState reference on fallback (never assumes nodes[size-1]);
 *              actual CloudSim VM instantiation verified via ModulePlacementMapping.getDeviceToModuleMap();
 *              runtime monotonicity guard + exact ascending linear-scan fallback preserved.
 *  - D-3.5-01: Cumulative Cloud fallback-demand telemetry (cloudFallbackDemandMips,
 *              cloudFallbackDemandRam, cloudFallbackDemandBw) plus per-module unmet
 *              resource deficit recording without decrementing cloudState below zero.
 */
public class ModulePlacementLBMP {

    /** Steady-state CPU demand for Sensor_Analyzer: 0.2 Hz * 3,500 MI = 700.0 MIPS (LAMP Table I). */
    public static final double SENSOR_ANALYZER_MIPS_DEMAND = 700.0;

    // -------------------------------------------------------------------------
    // Core Data Structures
    // -------------------------------------------------------------------------

    public static final class ResourceVector {
        public double mips;
        public int ramMb;
        public long bwUnits;

        public ResourceVector(double mips, int ramMb, long bwUnits) {
            this.mips = mips;
            this.ramMb = ramMb;
            this.bwUnits = bwUnits;
        }

        public ResourceVector copy() {
            return new ResourceVector(this.mips, this.ramMb, this.bwUnits);
        }

        @Override
        public String toString() {
            return String.format(Locale.US, "<MIPS=%.1f, RAM=%d MB, BW=%d>", mips, ramMb, bwUnits);
        }
    }

    public static final class NodeState {
        public final FogDevice device;
        public final String canonicalName;
        public final int tierRank;     // 0 = Gateway (d-*), 1 = Proxy (proxy-server), 2 = Cloud (cloud)
        public final int numericIdx;   // Gateway numeric index i, 0 otherwise
        public final boolean isCloud;
        public final ResourceVector initial;
        public final ResourceVector available;

        public NodeState(FogDevice device, String canonicalName, int tierRank, int numericIdx,
                         boolean isCloud, ResourceVector initial) {
            this.device = device;
            this.canonicalName = canonicalName;
            this.tierRank = tierRank;
            this.numericIdx = numericIdx;
            this.isCloud = isCloud;
            this.initial = initial.copy();
            this.available = initial.copy();
        }
    }

    public static final class ModuleRequest {
        public final String appId;
        public final String moduleName;
        public final String mobileName;
        public final int gatewayIdx;
        public final int mobileIdx;
        public final String localGwName; // Telemetry only — NEVER used in LBMP_PURE placement decisions
        public final ResourceVector required;

        public ModuleRequest(String appId, String moduleName, String mobileName,
                             int gatewayIdx, int mobileIdx, String localGwName, ResourceVector required) {
            this.appId = appId;
            this.moduleName = moduleName;
            this.mobileName = mobileName;
            this.gatewayIdx = gatewayIdx;
            this.mobileIdx = mobileIdx;
            this.localGwName = localGwName;
            this.required = required.copy();
        }
    }

    public static final class FallbackRecord {
        public final String appId;
        public final String moduleName;
        public final ResourceVector fullDemand;
        public final ResourceVector cloudAvailableAtFallback;
        public final double unmetDeficitMips;
        public final int unmetDeficitRam;
        public final long unmetDeficitBw;

        public FallbackRecord(String appId, String moduleName, ResourceVector fullDemand,
                              ResourceVector cloudAvailableAtFallback) {
            this.appId = appId;
            this.moduleName = moduleName;
            this.fullDemand = fullDemand.copy();
            this.cloudAvailableAtFallback = cloudAvailableAtFallback.copy();
            this.unmetDeficitMips = Math.max(0.0, fullDemand.mips - cloudAvailableAtFallback.mips);
            this.unmetDeficitRam = Math.max(0, fullDemand.ramMb - cloudAvailableAtFallback.ramMb);
            this.unmetDeficitBw = Math.max(0L, fullDemand.bwUnits - cloudAvailableAtFallback.bwUnits);
        }

        @Override
        public String toString() {
            return String.format(Locale.US,
                    "Fallback[%s (%s): demand=%s, cloudAvail=%s, unmetDeficit=<MIPS=%.1f, RAM=%d MB, BW=%d>]",
                    moduleName, appId, fullDemand, cloudAvailableAtFallback,
                    unmetDeficitMips, unmetDeficitRam, unmetDeficitBw);
        }
    }

    public static final class VmInstantiationFailure {
        public final String appId;
        public final String moduleName;
        public final String targetDeviceName;
        public final boolean wasCloudFallback;

        public VmInstantiationFailure(String appId, String moduleName, String targetDeviceName, boolean wasCloudFallback) {
            this.appId = appId;
            this.moduleName = moduleName;
            this.targetDeviceName = targetDeviceName;
            this.wasCloudFallback = wasCloudFallback;
        }

        @Override
        public String toString() {
            return "VmFailure[app=" + appId + ", module=" + moduleName
                    + ", target=" + targetDeviceName + ", wasCloudFallback=" + wasCloudFallback + "]";
        }
    }

    // -------------------------------------------------------------------------
    // Deterministic Total-Order Comparators (PHASE_3_4 Section 4)
    // -------------------------------------------------------------------------

    /**
     * Ascending node capacity comparator with explicit insertion-order-independent tie-breaking.
     * Tier rank breaks ONLY exact 3D capacity ties (never overrides available resources).
     */
    public static final Comparator<NodeState> NODE_ASC_COMPARATOR =
            Comparator.comparingDouble((NodeState n) -> n.available.mips)
                      .thenComparingInt(n -> n.available.ramMb)
                      .thenComparingLong(n -> n.available.bwUnits)
                      .thenComparingInt(n -> n.tierRank)
                      .thenComparingInt(n -> n.numericIdx)
                      .thenComparing(n -> n.canonicalName);

    /**
     * Ascending module demand comparator with explicit canonical tie-breaking.
     */
    public static final Comparator<ModuleRequest> MODULE_ASC_COMPARATOR =
            Comparator.comparingDouble((ModuleRequest m) -> m.required.mips)
                      .thenComparingInt(m -> m.required.ramMb)
                      .thenComparingLong(m -> m.required.bwUnits)
                      .thenComparingInt(m -> m.gatewayIdx)
                      .thenComparingInt(m -> m.mobileIdx)
                      .thenComparing(m -> m.moduleName);

    // -------------------------------------------------------------------------
    // Instance State & Audit Telemetry
    // -------------------------------------------------------------------------

    private final List<NodeState> candidateNodes = new ArrayList<>();
    private final NodeState cloudState;

    private final Map<String, ModulePlacement> placementsMap = new LinkedHashMap<>();
    private final Map<String, String> analyzerToDeviceMap = new LinkedHashMap<>();
    private final Map<String, String> analyzerPlacementTagMap = new LinkedHashMap<>();
    private final Map<String, String> allModuleToDeviceMap = new LinkedHashMap<>();

    // Analytical Sensor_Analyzer placement counters (Sum = N)
    private int analyzerLocalGw = 0;
    private int analyzerPeerGw = 0;
    private int analyzerProxy = 0;
    private int cloudSelectedNormalCount = 0;
    private int cloudFallbackCount = 0;

    // Planned fixed module counters
    private int plannedMobileInterfaces = 0;
    private int plannedCloudStorage = 0;

    // Search telemetry
    private int binarySearchCount = 0;
    private int linearFallbackCount = 0;

    // Cumulative Cloud fallback-demand telemetry (D-3.5-01)
    private double cloudFallbackDemandMips = 0.0;
    private int cloudFallbackDemandRam = 0;
    private long cloudFallbackDemandBw = 0L;
    private final List<FallbackRecord> fallbackRecords = new ArrayList<>();

    // Actual CloudSim VM instantiation verification (D-3.4-08)
    private int vmInstantiationSuccessCount = 0;
    private int vmInstantiationFailureCount = 0;
    private final List<VmInstantiationFailure> vmInstantiationFailures = new ArrayList<>();

    // Diagnostic logs
    private final List<String> warnings = new ArrayList<>();

    // -------------------------------------------------------------------------
    // Constructors
    // -------------------------------------------------------------------------

    /**
     * Production iFogSim constructor for Healthcare BSN applications.
     */
    public ModulePlacementLBMP(List<FogDevice> fogDevices, List<Application> applications) {
        if (fogDevices == null || fogDevices.isEmpty()) {
            throw new IllegalArgumentException("fogDevices must not be null or empty.");
        }
        if (applications == null) {
            throw new IllegalArgumentException("applications must not be null.");
        }

        NodeState foundCloud = null;
        Map<String, FogDevice> deviceByName = new HashMap<>();

        // 1. Build candidate nodes[] = N_F U {cloud} (Design C1: exclude mobile end devices m-*)
        for (FogDevice dev : fogDevices) {
            deviceByName.put(dev.getName(), dev);
            String name = dev.getName();
            if (name.startsWith("m-")) {
                // Tier 3 mobile end devices host pinned Interface_i_j only; excluded from nodes[]
                continue;
            }
            int tierRank;
            int numericIdx = 0;
            boolean isCloud = false;
            if (name.equals("cloud")) {
                tierRank = 2;
                isCloud = true;
            } else if (name.equals("proxy-server")) {
                tierRank = 1;
            } else if (name.startsWith("d-")) {
                tierRank = 0;
                numericIdx = parseGatewayIndex(name);
            } else {
                tierRank = 1;
            }

            // Option A BW (D-3.4-03): Host.getBw() (CloudSim VM-layer approximation)
            ResourceVector cap = new ResourceVector(
                    dev.getHost().getTotalMips(),
                    dev.getHost().getRam(),
                    dev.getHost().getBw()
            );
            NodeState ns = new NodeState(dev, name, tierRank, numericIdx, isCloud, cap);
            candidateNodes.add(ns);
            if (isCloud) {
                foundCloud = ns;
            }
        }

        if (foundCloud == null) {
            throw new IllegalArgumentException("Topology must contain a Cloud device named 'cloud'.");
        }
        this.cloudState = foundCloud;

        // 2. Build dynamic Sensor_Analyzer ModuleRequests and pre-reserve Cloud_Storage RAM/BW (D-3.4-07)
        List<ModuleRequest> requests = new ArrayList<>();
        Map<String, Application> appById = new HashMap<>();
        Map<String, String> suffixByAppId = new HashMap<>();

        for (Application app : applications) {
            String appId = app.getAppId();
            appById.put(appId, app);

            String suffix = extractSuffix(appId);
            suffixByAppId.put(appId, suffix);
            int[] indices = parseGatewayAndMobileIndex(suffix);
            int gwIdx = indices[0];
            int mobIdx = indices[1];

            String mobileName = "m-" + gwIdx + "-" + mobIdx;
            String localGwName = "d-" + gwIdx;
            String modAnalyzerName = HealthcareBSNApplication.MODULE_SENSOR_ANALYZER + "_" + suffix;
            String modStorageName = HealthcareBSNApplication.MODULE_CLOUD_STORAGE + "_" + suffix;

            AppModule analyzerModule = app.getModuleByName(modAnalyzerName);
            AppModule storageModule = app.getModuleByName(modStorageName);
            if (analyzerModule == null || storageModule == null) {
                throw new IllegalStateException("Missing required BSN modules in application: " + appId);
            }

            // Fixed-module accounting convention (D-3.4-07):
            // Pre-reserve Cloud_Storage RAM (10 MB) and Host BW (1,000) in LBMP analytical ledger;
            // intentionally exclude Cloud_Storage CPU to preserve LAMP/EWMP comparability.
            preReserveFixedCloudStorage(appId, modStorageName, storageModule.getRam(), storageModule.getBw());

            // Option A BW (D-3.4-03): AppModule.getBw() (CloudSim VM-layer approximation)
            ResourceVector demand = new ResourceVector(
                    SENSOR_ANALYZER_MIPS_DEMAND,
                    analyzerModule.getRam(),
                    analyzerModule.getBw()
            );
            requests.add(new ModuleRequest(appId, modAnalyzerName, mobileName, gwIdx, mobIdx, localGwName, demand));
        }

        // 3. Execute LBMP_PURE Algorithm 1 (MODULEMAP)
        executeModuleMap(requests);

        // 4. Construct ModulePlacementMapping per application and verify actual CloudSim VM instantiation (D-3.4-08)
        for (ModuleRequest req : requests) {
            String appId = req.appId;
            String suffix = suffixByAppId.get(appId);
            Application app = appById.get(appId);

            String modInterfaceName = HealthcareBSNApplication.MODULE_INTERFACE + "_" + suffix;
            String modAnalyzerName = req.moduleName;
            String modStorageName = HealthcareBSNApplication.MODULE_CLOUD_STORAGE + "_" + suffix;

            String chosenAnalyzerHost = analyzerToDeviceMap.get(modAnalyzerName);
            boolean analyzerWasFallback = "CLOUD_FALLBACK".equals(analyzerPlacementTagMap.get(modAnalyzerName));

            allModuleToDeviceMap.put(modInterfaceName, req.mobileName);
            allModuleToDeviceMap.put(modAnalyzerName, chosenAnalyzerHost);
            allModuleToDeviceMap.put(modStorageName, cloudState.canonicalName);

            plannedMobileInterfaces++;
            plannedCloudStorage++;

            ModuleMapping mapping = ModuleMapping.createModuleMapping();
            mapping.addModuleToDevice(modInterfaceName, req.mobileName);
            mapping.addModuleToDevice(modAnalyzerName, chosenAnalyzerHost);
            mapping.addModuleToDevice(modStorageName, cloudState.canonicalName);

            ModulePlacementMapping placement = new ModulePlacementMapping(fogDevices, app, mapping);
            placementsMap.put(appId, placement);

            // Verify actual CloudSim VM instantiation via placement.getDeviceToModuleMap() (D-3.4-08)
            verifyVmInstantiation(placement, appId, modInterfaceName, req.mobileName, deviceByName, false);
            verifyVmInstantiation(placement, appId, modAnalyzerName, chosenAnalyzerHost, deviceByName, analyzerWasFallback);
            verifyVmInstantiation(placement, appId, modStorageName, cloudState.canonicalName, deviceByName, false);
        }
    }

    /**
     * Synthetic unit-test constructor for pure algorithmic testing (T01-T06, T08a, T10)
     * without requiring a CloudSim runtime instance.
     */
    public ModulePlacementLBMP(List<NodeState> syntheticNodes, NodeState cloudState,
                               List<ModuleRequest> syntheticRequests) {
        if (syntheticNodes == null || cloudState == null || syntheticRequests == null) {
            throw new IllegalArgumentException("Synthetic constructor arguments must not be null.");
        }
        this.candidateNodes.addAll(syntheticNodes);
        this.cloudState = cloudState;
        executeModuleMap(new ArrayList<>(syntheticRequests));
    }

    // -------------------------------------------------------------------------
    // Core LBMP_PURE Algorithms (Taneja & Davy 2017, Algorithms 1-3)
    // -------------------------------------------------------------------------

    /**
     * Algorithm 3: COMPARE(NetworkNode a, AppModule b) (Taneja & Davy 2017, p. 1226).
     * Checks all 3 resource dimensions independently.
     *
     * @return 1 if eligible across CPU, RAM, and BW; -1 otherwise.
     */
    public static int compare(NodeState a, ModuleRequest b) {
        if (a.available.mips >= b.required.mips
                && a.available.ramMb >= b.required.ramMb
                && a.available.bwUnits >= b.required.bwUnits) {
            return 1;
        }
        return -1;
    }

    /**
     * Algorithm 1, Line 9: Atomic multi-resource capacity decrement.
     * Never called on unconditional fallback path (D-3.5-01).
     */
    public static void reserveResources(NodeState node, ModuleRequest mod) {
        if (compare(node, mod) != 1) {
            throw new IllegalStateException(
                    "Attempted to reserve resources on ineligible node " + node.canonicalName
                            + " (avail=" + node.available + ", req=" + mod.required + ")");
        }
        node.available.mips -= mod.required.mips;
        node.available.ramMb -= mod.required.ramMb;
        node.available.bwUnits -= mod.required.bwUnits;
    }

    /**
     * Algorithm 2: LOWERBOUND(nodes[], module, low, high) (Taneja & Davy 2017, p. 1226).
     * Verbatim while(true) binary search returning the smallest index i with COMPARE == 1, or -1.
     *
     * Caller guarantees: nodes is non-empty, low == 0, high == nodes.size() - 1,
     * and isEligibilityMonotonic(nodes, mod) == true.
     */
    public static int lowerBound(List<NodeState> nodes, ModuleRequest mod, int low, int high) {
        if (nodes == null || nodes.isEmpty() || low > high || low < 0 || high >= nodes.size()) {
            return -1;
        }
        int length = nodes.size();
        int mid = low + (high - low) / 2;
        while (true) {
            NodeState x = nodes.get(mid);
            if (compare(x, mod) == 1) {
                high = mid - 1;
                if (high < low) {
                    return mid;
                }
            } else {
                low = mid + 1;
                if (low > high) {
                    return (mid < length - 1) ? (mid + 1) : -1;
                }
            }
            mid = low + (high - low) / 2;
        }
    }

    /**
     * Runtime monotonicity guard (D-3.4-08): detects EVERY TRUE -> FALSE drop across nodes[].
     */
    public static boolean isEligibilityMonotonic(List<NodeState> nodes, ModuleRequest mod) {
        boolean seenEligible = false;
        for (NodeState node : nodes) {
            boolean eligible = (compare(node, mod) == 1);
            if (seenEligible && !eligible) {
                return false;
            }
            if (eligible) {
                seenEligible = true;
            }
        }
        return true;
    }

    /**
     * Multi-resource exact ascending linear-scan fallback (D-3.4-08).
     * Invoked ONLY when isEligibilityMonotonic returns false.
     */
    public static int linearLowerBoundScan(List<NodeState> nodes, ModuleRequest mod) {
        for (int k = 0; k < nodes.size(); k++) {
            if (compare(nodes.get(k), mod) == 1) {
                return k;
            }
        }
        return -1;
    }

    /**
     * Algorithm 1: MODULEMAP (Taneja & Davy 2017, p. 1225) with D-3.4-01..D-3.4-08 and D-3.5-01.
     */
    private void executeModuleMap(List<ModuleRequest> requests) {
        // Algorithm 1, Line 2: Sort nodes[] and modules[] in ascending order
        candidateNodes.sort(NODE_ASC_COMPARATOR);
        requests.sort(MODULE_ASC_COMPARATOR);

        // Algorithm 1, Line 5: Iterate over sorted modules
        for (ModuleRequest mod : requests) {
            // D-3.4-04: Multi-app adaptation — reset low = 0 after every dynamic re-sort
            int low = 0;
            int high = candidateNodes.size() - 1;

            int idx;
            if (isEligibilityMonotonic(candidateNodes, mod)) {
                idx = lowerBound(candidateNodes, mod, low, high);
                binarySearchCount++;
            } else {
                String warn = "[LBMP_WARN] Non-monotonic 3D eligibility detected for " + mod.moduleName
                        + "; falling back from binary search to exact ascending linear scan.";
                warnings.add(warn);
                idx = linearLowerBoundScan(candidateNodes, mod);
                linearFallbackCount++;
            }

            if (idx != -1) {
                // Path 1: Normal selection (Fog OR Cloud via COMPARE == 1)
                NodeState chosen = candidateNodes.get(idx);
                assignAnalyzerNormal(mod, chosen);

                // Algorithm 1, Line 9-10: Atomic 3D capacity decrement + mandatory ascending re-sort
                reserveResources(chosen, mod);
                candidateNodes.sort(NODE_ASC_COMPARATOR);
            } else {
                // Path 2: Unconditional Cloud fallback (Algorithm 1, Line 13)
                // D-3.4-08: Always target explicit cloudState reference (never nodes.get(nodes.size() - 1))
                // D-3.5-01: Record unmet deficit & accumulate full demand; NEVER decrement cloudState below zero
                assignAnalyzerCloudFallback(mod);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Placement Recording & Verification Helpers
    // -------------------------------------------------------------------------

    private void preReserveFixedCloudStorage(String appId, String modStorageName, int ramMb, long bwUnits) {
        // Fixed-module accounting convention (D-3.4-07):
        // Pre-reserve RAM & Host BW only; intentionally exclude Cloud_Storage CPU.
        if (cloudState.available.ramMb >= ramMb) {
            cloudState.available.ramMb -= ramMb;
        } else {
            warnings.add("[LBMP_WARN] Cloud_Storage RAM pre-reservation shortfall for " + modStorageName
                    + " (" + appId + "): need=" + ramMb + ", avail=" + cloudState.available.ramMb
                    + "; leaving cloudState.available.ramMb non-negative.");
        }
        if (cloudState.available.bwUnits >= bwUnits) {
            cloudState.available.bwUnits -= bwUnits;
        } else {
            warnings.add("[LBMP_WARN] Cloud_Storage BW pre-reservation shortfall for " + modStorageName
                    + " (" + appId + "): need=" + bwUnits + ", avail=" + cloudState.available.bwUnits
                    + "; leaving cloudState.available.bwUnits non-negative.");
        }
    }

    private void assignAnalyzerNormal(ModuleRequest mod, NodeState chosen) {
        analyzerToDeviceMap.put(mod.moduleName, chosen.canonicalName);
        if (chosen == cloudState || chosen.isCloud) {
            cloudSelectedNormalCount++;
            analyzerPlacementTagMap.put(mod.moduleName, "CLOUD_NORMAL");
        } else if (chosen.canonicalName.equals("proxy-server")) {
            analyzerProxy++;
            analyzerPlacementTagMap.put(mod.moduleName, "PROXY");
        } else if (chosen.canonicalName.equals(mod.localGwName)) {
            analyzerLocalGw++;
            analyzerPlacementTagMap.put(mod.moduleName, "LOCAL_GW");
        } else {
            analyzerPeerGw++;
            analyzerPlacementTagMap.put(mod.moduleName, "PEER_GW");
        }
    }

    private void assignAnalyzerCloudFallback(ModuleRequest mod) {
        analyzerToDeviceMap.put(mod.moduleName, cloudState.canonicalName);
        analyzerPlacementTagMap.put(mod.moduleName, "CLOUD_FALLBACK");
        cloudFallbackCount++;

        // D-3.5-01: Record individual unmet deficit & accumulate FULL demand; do NOT decrement cloudState
        FallbackRecord record = new FallbackRecord(mod.appId, mod.moduleName, mod.required, cloudState.available);
        fallbackRecords.add(record);
        cloudFallbackDemandMips += mod.required.mips;
        cloudFallbackDemandRam += mod.required.ramMb;
        cloudFallbackDemandBw += mod.required.bwUnits;

        warnings.add("[LBMP_WARN] Unconditional Cloud fallback triggered for " + record);
    }

    private void verifyVmInstantiation(ModulePlacementMapping placement, String appId,
                                       String moduleName, String targetDeviceName,
                                       Map<String, FogDevice> deviceByName, boolean wasCloudFallback) {
        FogDevice targetDevice = deviceByName.get(targetDeviceName);
        boolean instantiated = false;
        if (targetDevice != null && placement.getDeviceToModuleMap() != null) {
            List<AppModule> hosted = placement.getDeviceToModuleMap().get(targetDevice.getId());
            if (hosted != null) {
                for (AppModule m : hosted) {
                    if (m.getName().equals(moduleName)) {
                        instantiated = true;
                        break;
                    }
                }
            }
        }

        if (instantiated) {
            vmInstantiationSuccessCount++;
        } else {
            vmInstantiationFailureCount++;
            VmInstantiationFailure failure = new VmInstantiationFailure(
                    appId, moduleName, targetDeviceName, wasCloudFallback);
            vmInstantiationFailures.add(failure);
            warnings.add("[LBMP_VM_FAILURE] CloudSim VM instantiation failed: " + failure);
        }
    }

    private static int parseGatewayIndex(String gwName) {
        try {
            return Integer.parseInt(gwName.substring(2));
        } catch (Exception e) {
            return Integer.MAX_VALUE;
        }
    }

    private static String extractSuffix(String appId) {
        if (appId.startsWith("app_")) {
            return appId.substring(4);
        }
        int firstUnderscore = appId.indexOf('_');
        return (firstUnderscore >= 0) ? appId.substring(firstUnderscore + 1) : appId;
    }

    private static int[] parseGatewayAndMobileIndex(String suffix) {
        String[] parts = suffix.split("_");
        if (parts.length >= 2) {
            try {
                return new int[] { Integer.parseInt(parts[0]), Integer.parseInt(parts[1]) };
            } catch (NumberFormatException ignored) {
            }
        }
        return new int[] { 0, 0 };
    }

    // -------------------------------------------------------------------------
    // Public Getters for Accounting, Telemetry & Diagnostics
    // -------------------------------------------------------------------------

    public Map<String, ModulePlacement> getPlacementsMap() {
        return Collections.unmodifiableMap(placementsMap);
    }

    public ModulePlacement getPlacementForApp(String appId) {
        return placementsMap.get(appId);
    }

    public Map<String, String> getAnalyzerToDeviceMap() {
        return Collections.unmodifiableMap(analyzerToDeviceMap);
    }

    public Map<String, String> getAnalyzerPlacementTagMap() {
        return Collections.unmodifiableMap(analyzerPlacementTagMap);
    }

    public Map<String, String> getAllModuleToDeviceMap() {
        return Collections.unmodifiableMap(allModuleToDeviceMap);
    }

    public List<NodeState> getCandidateNodes() {
        return Collections.unmodifiableList(candidateNodes);
    }

    public NodeState getCloudState() {
        return cloudState;
    }

    public NodeState getNodeStateByName(String canonicalName) {
        for (NodeState ns : candidateNodes) {
            if (ns.canonicalName.equals(canonicalName)) {
                return ns;
            }
        }
        return null;
    }

    public int getAnalyzerLocalGw() { return analyzerLocalGw; }
    public int getAnalyzerPeerGw() { return analyzerPeerGw; }
    public int getAnalyzerProxy() { return analyzerProxy; }
    public int getCloudSelectedNormalCount() { return cloudSelectedNormalCount; }
    public int getCloudFallbackCount() { return cloudFallbackCount; }
    public int getTotalAnalyzerCloud() { return cloudSelectedNormalCount + cloudFallbackCount; }
    public int getTotalAnalyzerFog() { return analyzerLocalGw + analyzerPeerGw + analyzerProxy; }
    public int getTotalAnalyzers() { return getTotalAnalyzerFog() + getTotalAnalyzerCloud(); }

    public int getPlannedFogModules() { return plannedMobileInterfaces + getTotalAnalyzerFog(); }
    public int getPlannedCloudModules() { return plannedCloudStorage + getTotalAnalyzerCloud(); }
    public int getPlannedSystemModules() { return getPlannedFogModules() + getPlannedCloudModules(); }

    public int getBinarySearchCount() { return binarySearchCount; }
    public int getLinearFallbackCount() { return linearFallbackCount; }

    public double getCloudFallbackDemandMips() { return cloudFallbackDemandMips; }
    public int getCloudFallbackDemandRam() { return cloudFallbackDemandRam; }
    public long getCloudFallbackDemandBw() { return cloudFallbackDemandBw; }
    public List<FallbackRecord> getFallbackRecords() { return Collections.unmodifiableList(fallbackRecords); }

    public int getVmInstantiationSuccessCount() { return vmInstantiationSuccessCount; }
    public int getVmInstantiationFailureCount() { return vmInstantiationFailureCount; }
    public List<VmInstantiationFailure> getVmInstantiationFailures() {
        return Collections.unmodifiableList(vmInstantiationFailures);
    }

    public List<String> getWarnings() { return Collections.unmodifiableList(warnings); }
}
