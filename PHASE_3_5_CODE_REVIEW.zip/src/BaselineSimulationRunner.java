package org.fog.lamp.baselines;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.core.CloudSim;
import org.fog.application.AppLoop;
import org.fog.application.Application;
import org.fog.entities.Actuator;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.Sensor;
import org.fog.lamp.application.HealthcareBSNApplication;
import org.fog.lamp.asymmetric.AsymmetricTopologyFactory;
import org.fog.lamp.baselines.ModulePlacementLBMP.FallbackRecord;
import org.fog.lamp.baselines.ModulePlacementLBMP.NodeState;
import org.fog.lamp.baselines.ModulePlacementLBMP.VmInstantiationFailure;
import org.fog.lamp.topology.HealthcareTopologyFactory;
import org.fog.placement.Controller;
import org.fog.placement.ModulePlacement;
import org.fog.utils.Config;
import org.fog.utils.NetworkUsageMonitor;
import org.fog.utils.TimeKeeper;

/**
 * Isolated LBMP_PURE Simulation Runner (Phase 3.5).
 * Supports both Symmetric (Phase 2 matrix: 2/3/4 GW x 2/4/6/8 mobiles) and
 * Asymmetric (Phase 2.2 matrix: [6,2], [2,6], [6,6], [10,2]) Healthcare BSN topologies.
 *
 * Reuses existing read-only HealthcareTopologyFactory, AsymmetricTopologyFactory,
 * and HealthcareBSNApplication without modifying any historical code or datasets.
 *
 * Usage:
 *   Symmetric:  java org.fog.lamp.baselines.BaselineSimulationRunner SYMMETRIC <numGateways> <numMobilesPerGw> [simTime]
 *   Asymmetric: java org.fog.lamp.baselines.BaselineSimulationRunner ASYMMETRIC <gw0Mobiles> <gw1Mobiles> [simTime]
 */
public class BaselineSimulationRunner {

    public static final String ALGORITHM_LABEL = "LBMP_PURE";
    public static final double SENSOR_INTERVAL_SEC = 5.0;

    public static void main(String[] args) {
        if (args.length < 3) {
            System.err.println("Usage:");
            System.err.println("  SYMMETRIC <numGateways> <numMobilesPerGw> [simTime]");
            System.err.println("  ASYMMETRIC <gw0Mobiles> <gw1Mobiles> [simTime]");
            System.exit(2);
        }

        String mode = args[0].toUpperCase(Locale.US);
        int arg1 = Integer.parseInt(args[1]);
        int arg2 = Integer.parseInt(args[2]);
        int simTime = (args.length >= 4) ? Integer.parseInt(args[3]) : 2000;

        if (!mode.equals("SYMMETRIC") && !mode.equals("ASYMMETRIC")) {
            System.err.println("Invalid mode: " + mode + " (expected SYMMETRIC or ASYMMETRIC)");
            System.exit(2);
        }

        Config.MAX_SIMULATION_TIME = simTime;

        int numGateways = mode.equals("SYMMETRIC") ? arg1 : 2;
        int[] mobilesPerGw = mode.equals("SYMMETRIC")
                ? fillUniform(arg1, arg2)
                : new int[] { arg1, arg2 };
        int totalApplications = 0;
        for (int m : mobilesPerGw) totalApplications += m;

        String workloadLabel = mode.equals("SYMMETRIC")
                ? (arg1 + "gw_" + arg2 + "mob")
                : (arg1 + "_" + arg2);

        System.out.println("================================================================================");
        System.out.println(" LAMP BASELINE SIMULATION RUNNER — " + ALGORITHM_LABEL + " (" + mode + ")");
        System.out.println(" Workload: " + workloadLabel + " | Gateways: " + numGateways + " | Total Apps: " + totalApplications);
        System.out.println(" Simulation Duration: " + Config.MAX_SIMULATION_TIME + " simulation ticks");
        System.out.println("================================================================================");

        try {
            Log.disable();
            CloudSim.init(1, Calendar.getInstance(), false);
            FogBroker broker = new FogBroker("broker");

            List<FogDevice> fogDevices;
            List<Sensor> sensors;
            List<Actuator> actuators;
            FogDevice cloud;

            if (mode.equals("SYMMETRIC")) {
                HealthcareTopologyFactory.TopologyContainer tc =
                        HealthcareTopologyFactory.createTopology(broker.getId(), arg1, arg2, SENSOR_INTERVAL_SEC);
                fogDevices = tc.fogDevices;
                sensors = tc.sensors;
                actuators = tc.actuators;
                cloud = tc.cloud;
            } else {
                AsymmetricTopologyFactory.TopologyContainer tc =
                        AsymmetricTopologyFactory.createAsymmetricTopology(broker.getId(), mobilesPerGw, SENSOR_INTERVAL_SEC);
                fogDevices = tc.fogDevices;
                sensors = tc.sensors;
                actuators = tc.actuators;
                cloud = tc.cloud;
            }

            // Build scoped BSN applications (identical to Phase 2 & Phase 2.2)
            List<Application> apps = new ArrayList<>();
            for (int i = 0; i < mobilesPerGw.length; i++) {
                for (int j = 0; j < mobilesPerGw[i]; j++) {
                    String suffix = i + "_" + j;
                    String appId = "app_" + suffix;
                    Application app = HealthcareBSNApplication.createApplication(appId, broker.getId(), suffix);
                    app.setUserId(broker.getId());
                    apps.add(app);
                }
            }

            Controller controller = new Controller("master-controller", fogDevices, sensors, actuators);

            // Solve LBMP_PURE placements (Design C1, Option A BW, low=0 reset, D-3.4-01..08 & D-3.5-01)
            ModulePlacementLBMP lbmp = new ModulePlacementLBMP(fogDevices, apps);

            // Log placement distribution, VM instantiation verification, search & fallback telemetry
            printPlacementAudit(lbmp, totalApplications);

            // Submit all applications to Controller
            List<Integer> expectedLoopIds = new ArrayList<>();
            for (Application app : apps) {
                ModulePlacement placement = lbmp.getPlacementForApp(app.getAppId());
                controller.submitApplication(app, 0, placement);
                for (AppLoop loop : app.getLoops()) {
                    expectedLoopIds.add(loop.getLoopId());
                }
            }

            final String finalMode = mode;
            final int finalArg1 = arg1;
            final int finalArg2 = arg2;
            final String finalWorkloadLabel = workloadLabel;
            final int finalTotalApps = totalApplications;
            final List<FogDevice> finalDevices = fogDevices;
            final FogDevice finalCloud = cloud;
            final List<Integer> finalExpectedLoopIds = expectedLoopIds;

            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    int completedLoops = 0;
                    double totalWeightedDelay = 0.0;
                    int totalExecutions = 0;

                    for (Integer loopId : finalExpectedLoopIds) {
                        Integer count = TimeKeeper.getInstance().getLoopIdToCurrentNum().get(loopId);
                        Double avg = TimeKeeper.getInstance().getLoopIdToCurrentAverage().get(loopId);
                        if (count != null && count > 0 && avg != null && !avg.isNaN()) {
                            completedLoops++;
                            totalWeightedDelay += (avg * count);
                            totalExecutions += count;
                        }
                    }

                    String status;
                    String loopDelayStr;
                    if (completedLoops == finalTotalApps && totalExecutions > 0) {
                        status = "SUCCESS";
                        loopDelayStr = String.format(Locale.US, "%.4f", totalWeightedDelay / totalExecutions);
                    } else if (completedLoops > 0) {
                        status = "PARTIAL_COMPLETION";
                        loopDelayStr = String.format(Locale.US, "%.4f", totalWeightedDelay / totalExecutions);
                    } else {
                        status = "NO_COMPLETION";
                        loopDelayStr = "N/A";
                    }

                    double cloudEnergy = finalCloud.getEnergyConsumption();
                    double fogEnergy = 0.0;
                    for (FogDevice dev : finalDevices) {
                        if (!dev.getName().equals("cloud")) {
                            fogEnergy += dev.getEnergyConsumption();
                        }
                    }
                    double cloudCost = finalCloud.getTotalCost();
                    double networkUsage = NetworkUsageMonitor.getNetworkUsage() / Config.MAX_SIMULATION_TIME;

                    System.out.println("\n================================================================================");
                    System.out.println("LBMP_PURE EXPERIMENT RESULTS (" + finalMode + ")");
                    System.out.println("Algorithm: " + ALGORITHM_LABEL + " | Workload: " + finalWorkloadLabel + " | Total Apps: " + finalTotalApps);
                    System.out.println("Loop Delay (sim ticks): " + loopDelayStr);
                    System.out.println("Loops Completed: " + completedLoops + " / " + finalTotalApps + " (Executions: " + totalExecutions + ")");
                    System.out.println("Cloud Energy (J): " + String.format(Locale.US, "%.4f", cloudEnergy));
                    System.out.println("Fog Energy (J): " + String.format(Locale.US, "%.4f", fogEnergy));
                    System.out.println("Cloud Cost ($): " + String.format(Locale.US, "%.6f", cloudCost));
                    System.out.println("Network Usage: " + String.format(Locale.US, "%.4f", networkUsage));
                    System.out.println("Status: " + status);
                    System.out.println("================================================================================");

                    if (finalMode.equals("SYMMETRIC")) {
                        System.out.println("LBMP_SYMM_CSV_ROW:" + ALGORITHM_LABEL + "," + finalArg1 + "," + finalArg2 + "," + finalTotalApps + ","
                                + loopDelayStr + ","
                                + String.format(Locale.US, "%.4f", cloudEnergy) + ","
                                + String.format(Locale.US, "%.4f", fogEnergy) + ","
                                + String.format(Locale.US, "%.6f", cloudCost) + ","
                                + String.format(Locale.US, "%.4f", networkUsage) + ","
                                + lbmp.getAnalyzerLocalGw() + "," + lbmp.getAnalyzerPeerGw() + "," + lbmp.getAnalyzerProxy() + ","
                                + lbmp.getCloudSelectedNormalCount() + "," + lbmp.getCloudFallbackCount() + ","
                                + lbmp.getPlannedFogModules() + "," + lbmp.getPlannedCloudModules() + "," + lbmp.getPlannedSystemModules() + ","
                                + lbmp.getVmInstantiationSuccessCount() + "," + lbmp.getVmInstantiationFailureCount() + ","
                                + lbmp.getBinarySearchCount() + "," + lbmp.getLinearFallbackCount() + ","
                                + String.format(Locale.US, "%.1f", lbmp.getCloudFallbackDemandMips()) + ","
                                + lbmp.getCloudFallbackDemandRam() + "," + lbmp.getCloudFallbackDemandBw() + ","
                                + completedLoops + "," + status);
                    } else {
                        System.out.println("LBMP_ASYM_CSV_ROW:" + ALGORITHM_LABEL + "," + finalWorkloadLabel + "," + finalTotalApps + ","
                                + loopDelayStr + ","
                                + String.format(Locale.US, "%.4f", cloudEnergy) + ","
                                + String.format(Locale.US, "%.4f", fogEnergy) + ","
                                + String.format(Locale.US, "%.6f", cloudCost) + ","
                                + String.format(Locale.US, "%.4f", networkUsage) + ","
                                + lbmp.getAnalyzerLocalGw() + "," + lbmp.getAnalyzerPeerGw() + "," + lbmp.getAnalyzerProxy() + ","
                                + lbmp.getCloudSelectedNormalCount() + "," + lbmp.getCloudFallbackCount() + ","
                                + lbmp.getPlannedFogModules() + "," + lbmp.getPlannedCloudModules() + "," + lbmp.getPlannedSystemModules() + ","
                                + lbmp.getVmInstantiationSuccessCount() + "," + lbmp.getVmInstantiationFailureCount() + ","
                                + lbmp.getBinarySearchCount() + "," + lbmp.getLinearFallbackCount() + ","
                                + String.format(Locale.US, "%.1f", lbmp.getCloudFallbackDemandMips()) + ","
                                + lbmp.getCloudFallbackDemandRam() + "," + lbmp.getCloudFallbackDemandBw() + ","
                                + completedLoops + "," + status);
                    }
                } catch (Exception e) {
                    System.err.println("Error extracting metrics in shutdown hook: " + e.getMessage());
                }
            }));

            TimeKeeper.getInstance().setSimulationStartTime(Calendar.getInstance().getTimeInMillis());
            CloudSim.startSimulation();
            CloudSim.stopSimulation();

        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void printPlacementAudit(ModulePlacementLBMP lbmp, int totalApplications) {
        System.out.println("\n[LBMP_PURE Placement Distribution & Telemetry]");
        System.out.println("  Sensor_Analyzer on Local Gateway:  " + lbmp.getAnalyzerLocalGw());
        System.out.println("  Sensor_Analyzer on Peer Gateway:   " + lbmp.getAnalyzerPeerGw());
        System.out.println("  Sensor_Analyzer on Proxy Server:   " + lbmp.getAnalyzerProxy());
        System.out.println("  Sensor_Analyzer on Cloud (Normal): " + lbmp.getCloudSelectedNormalCount());
        System.out.println("  Sensor_Analyzer on Cloud (Fallback):" + lbmp.getCloudFallbackCount());
        System.out.println("  Total Analyzers: " + lbmp.getTotalAnalyzers() + " (Expected: " + totalApplications + ")");
        System.out.println("  Planned System Modules -> Fog: " + lbmp.getPlannedFogModules()
                + " | Cloud: " + lbmp.getPlannedCloudModules()
                + " | Grand Total: " + lbmp.getPlannedSystemModules() + " (Expected: " + (3 * totalApplications) + ")");
        System.out.println("  CloudSim VM Instantiation -> Success: " + lbmp.getVmInstantiationSuccessCount()
                + " | Failures: " + lbmp.getVmInstantiationFailureCount());
        System.out.println("  Search Telemetry -> BinarySearch: " + lbmp.getBinarySearchCount()
                + " | LinearFallback: " + lbmp.getLinearFallbackCount());
        System.out.println("  Cumulative Cloud Fallback Demand -> MIPS: "
                + String.format(Locale.US, "%.1f", lbmp.getCloudFallbackDemandMips())
                + " | RAM: " + lbmp.getCloudFallbackDemandRam()
                + " MB | BW: " + lbmp.getCloudFallbackDemandBw());

        if (!lbmp.getFallbackRecords().isEmpty()) {
            System.out.println("  Individual Cloud Fallback Records:");
            for (FallbackRecord rec : lbmp.getFallbackRecords()) {
                System.out.println("    " + rec);
            }
        }
        if (!lbmp.getVmInstantiationFailures().isEmpty()) {
            System.out.println("  CloudSim VM Instantiation Failures:");
            for (VmInstantiationFailure f : lbmp.getVmInstantiationFailures()) {
                System.out.println("    " + f);
            }
        }

        System.out.println("\n[Final Candidate Node Remaining Ledger]");
        for (NodeState ns : lbmp.getCandidateNodes()) {
            System.out.println("  " + ns.canonicalName + " -> remaining=" + ns.available + " (initial=" + ns.initial + ")");
        }

        System.out.println("\n[Analytical Module-to-Device Mappings]");
        Map<String, String> tags = lbmp.getAnalyzerPlacementTagMap();
        for (Map.Entry<String, String> entry : lbmp.getAnalyzerToDeviceMap().entrySet()) {
            System.out.println("  " + entry.getKey() + " -> " + entry.getValue() + " [" + tags.get(entry.getKey()) + "]");
        }
    }

    private static int[] fillUniform(int count, int value) {
        int[] arr = new int[count];
        for (int i = 0; i < count; i++) arr[i] = value;
        return arr;
    }
}
