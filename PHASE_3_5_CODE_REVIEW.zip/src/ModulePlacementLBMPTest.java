package org.fog.lamp.baselines;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.sdn.overbooking.BwProvisionerOverbooking;
import org.cloudbus.cloudsim.sdn.overbooking.PeProvisionerOverbooking;
import org.fog.application.Application;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.lamp.application.HealthcareBSNApplication;
import org.fog.lamp.asymmetric.AsymmetricTopologyFactory;
import org.fog.lamp.baselines.ModulePlacementLBMP.FallbackRecord;
import org.fog.lamp.baselines.ModulePlacementLBMP.ModuleRequest;
import org.fog.lamp.baselines.ModulePlacementLBMP.NodeState;
import org.fog.lamp.baselines.ModulePlacementLBMP.ResourceVector;
import org.fog.lamp.baselines.ModulePlacementLBMP.VmInstantiationFailure;
import org.fog.lamp.topology.HealthcareTopologyFactory;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.scheduler.StreamOperatorScheduler;
import org.fog.utils.FogLinearPowerModel;
import org.fog.utils.FogUtils;

/**
 * Deterministic Unit Test Suite for ModulePlacementLBMP (Phase 3.5).
 * Covers all 11 required validation scenarios (T01-T11) from PHASE_3_4_LBMP_DESIGN_SPECIFICATION.md
 * plus D-3.5-01 cumulative Cloud fallback-demand telemetry and VM instantiation verification.
 */
public class ModulePlacementLBMPTest {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {
        Log.disable();
        System.out.println("================================================================================");
        System.out.println(" PHASE 3.5 UNIT TEST SUITE: ModulePlacementLBMP (LBMP_PURE)");
        System.out.println("================================================================================");

        runTest("T01: Resource Equality Boundary", ModulePlacementLBMPTest::testT01_ResourceEqualityBoundary);
        runTest("T02: Insufficient CPU Independently", ModulePlacementLBMPTest::testT02_InsufficientCpu);
        runTest("T03: Insufficient RAM Independently", ModulePlacementLBMPTest::testT03_InsufficientRam);
        runTest("T04: Insufficient BW Independently", ModulePlacementLBMPTest::testT04_InsufficientBw);
        runTest("T05: Multiple Modules w/ Dynamic Re-Sorting", ModulePlacementLBMPTest::testT05_MultipleModulesReSorting);
        runTest("T06: low = 0 Boundary Reset Verification", ModulePlacementLBMPTest::testT06_LowBoundaryReset);
        runTest("T07: Cloud Selected by Normal Comparison (iFogSim)", ModulePlacementLBMPTest::testT07_CloudNormalSelection);
        runTest("T08: Cloud Fallback, Cumulative Demand & VM Failure Separation", ModulePlacementLBMPTest::testT08_CloudFallbackAndVmFailure);
        runTest("T09: Deterministic Tie Handling (5 Permutations)", ModulePlacementLBMPTest::testT09_DeterministicTieHandling);
        runTest("T10: Monotonicity Guard & Linear-Scan Fallback", ModulePlacementLBMPTest::testT10_MonotonicityGuardAndLinearFallback);
        runTest("T11: Exact 3N Module & VM Accounting (N=4,8,12,16,32)", ModulePlacementLBMPTest::testT11_Exact3NAccounting);

        System.out.println("================================================================================");
        System.out.println(" SUMMARY: " + passed + " PASSED, " + failed + " FAILED (Total: " + (passed + failed) + ")");
        System.out.println("================================================================================");
        if (failed > 0) {
            System.exit(1);
        }
    }

    private static void runTest(String name, Runnable test) {
        try {
            test.run();
            passed++;
            System.out.println("  [PASS] " + name);
        } catch (Throwable t) {
            failed++;
            System.err.println("  [FAIL] " + name + " -> " + t.getMessage());
            t.printStackTrace(System.err);
        }
    }

    private static void assertTrue(boolean cond, String msg) {
        if (!cond) throw new AssertionError(msg);
    }

    private static void assertEquals(long expected, long actual, String msg) {
        if (expected != actual) {
            throw new AssertionError(msg + " (expected=" + expected + ", actual=" + actual + ")");
        }
    }

    private static void assertEquals(double expected, double actual, double eps, String msg) {
        if (Math.abs(expected - actual) > eps) {
            throw new AssertionError(msg + " (expected=" + expected + ", actual=" + actual + ")");
        }
    }

    private static void assertEquals(String expected, String actual, String msg) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError(msg + " (expected=" + expected + ", actual=" + actual + ")");
        }
    }

    private static NodeState gwNode(int idx, double mips, int ram, long bw) {
        return new NodeState(null, "d-" + idx, 0, idx, false, new ResourceVector(mips, ram, bw));
    }

    private static NodeState proxyNode(double mips, int ram, long bw) {
        return new NodeState(null, "proxy-server", 1, 0, false, new ResourceVector(mips, ram, bw));
    }

    private static NodeState cloudNode(double mips, int ram, long bw) {
        return new NodeState(null, "cloud", 2, 0, true, new ResourceVector(mips, ram, bw));
    }

    private static ModuleRequest req(int gwIdx, int mobIdx, double mips, int ram, long bw) {
        String sfx = gwIdx + "_" + mobIdx;
        return new ModuleRequest("app_" + sfx, "Sensor_Analyzer_" + sfx,
                "m-" + gwIdx + "-" + mobIdx, gwIdx, mobIdx, "d-" + gwIdx,
                new ResourceVector(mips, ram, bw));
    }

    // -------------------------------------------------------------------------
    // T01: Resource Equality Boundary
    // -------------------------------------------------------------------------
    private static void testT01_ResourceEqualityBoundary() {
        NodeState fog = gwNode(0, 700.0, 10, 1000L);
        NodeState cloud = cloudNode(44800.0, 40000, 1000000L);
        ModuleRequest m = req(0, 0, 700.0, 10, 1000L);

        assertEquals(1, ModulePlacementLBMP.compare(fog, m), "Boundary equality must return 1");
        ModulePlacementLBMP solver = new ModulePlacementLBMP(Arrays.asList(fog, cloud), cloud, Collections.singletonList(m));

        assertEquals("d-0", solver.getAnalyzerToDeviceMap().get("Sensor_Analyzer_0_0"), "Should place on d-0");
        assertEquals(0.0, fog.available.mips, 1e-9, "Fog remaining MIPS must be 0");
        assertEquals(0, fog.available.ramMb, "Fog remaining RAM must be 0");
        assertEquals(0L, fog.available.bwUnits, "Fog remaining BW must be 0");
        assertEquals(0, solver.getCloudSelectedNormalCount(), "No normal Cloud placement");
        assertEquals(0, solver.getCloudFallbackCount(), "No Cloud fallback");
    }

    // -------------------------------------------------------------------------
    // T02: Insufficient CPU Independently
    // -------------------------------------------------------------------------
    private static void testT02_InsufficientCpu() {
        NodeState fog = gwNode(0, 699.9, 4000, 1000000L);
        NodeState cloud = cloudNode(44800.0, 40000, 1000000L);
        ModuleRequest m = req(0, 0, 700.0, 10, 1000L);

        assertEquals(-1, ModulePlacementLBMP.compare(fog, m), "Insufficient CPU must fail compare");
        ModulePlacementLBMP solver = new ModulePlacementLBMP(Arrays.asList(fog, cloud), cloud, Collections.singletonList(m));

        assertEquals("cloud", solver.getAnalyzerToDeviceMap().get("Sensor_Analyzer_0_0"), "Should place on cloud");
        assertEquals(1, solver.getCloudSelectedNormalCount(), "Cloud selected via normal comparison");
        assertEquals(0, solver.getCloudFallbackCount(), "No Cloud fallback");
    }

    // -------------------------------------------------------------------------
    // T03: Insufficient RAM Independently
    // -------------------------------------------------------------------------
    private static void testT03_InsufficientRam() {
        NodeState fog = gwNode(0, 2800.0, 9, 1000000L);
        NodeState cloud = cloudNode(44800.0, 40000, 1000000L);
        ModuleRequest m = req(0, 0, 700.0, 10, 1000L);

        assertEquals(-1, ModulePlacementLBMP.compare(fog, m), "Insufficient RAM must fail compare");
        ModulePlacementLBMP solver = new ModulePlacementLBMP(Arrays.asList(fog, cloud), cloud, Collections.singletonList(m));

        assertEquals("cloud", solver.getAnalyzerToDeviceMap().get("Sensor_Analyzer_0_0"), "Should place on cloud");
        assertEquals(1, solver.getCloudSelectedNormalCount(), "Cloud selected via normal comparison");
        assertEquals(0, solver.getCloudFallbackCount(), "No Cloud fallback");
    }

    // -------------------------------------------------------------------------
    // T04: Insufficient BW Independently
    // -------------------------------------------------------------------------
    private static void testT04_InsufficientBw() {
        NodeState fog = gwNode(0, 2800.0, 4000, 999L);
        NodeState cloud = cloudNode(44800.0, 40000, 1000000L);
        ModuleRequest m = req(0, 0, 700.0, 10, 1000L);

        assertEquals(-1, ModulePlacementLBMP.compare(fog, m), "Insufficient BW must fail compare");
        ModulePlacementLBMP solver = new ModulePlacementLBMP(Arrays.asList(fog, cloud), cloud, Collections.singletonList(m));

        assertEquals("cloud", solver.getAnalyzerToDeviceMap().get("Sensor_Analyzer_0_0"), "Should place on cloud");
        assertEquals(1, solver.getCloudSelectedNormalCount(), "Cloud selected via normal comparison");
        assertEquals(0, solver.getCloudFallbackCount(), "No Cloud fallback");
    }

    // -------------------------------------------------------------------------
    // T05: Multiple Modules w/ Dynamic Re-Sorting
    // -------------------------------------------------------------------------
    private static void testT05_MultipleModulesReSorting() {
        NodeState d0 = gwNode(0, 2800.0, 4000, 1000000L);
        NodeState d1 = gwNode(1, 2800.0, 4000, 1000000L);
        NodeState proxy = proxyNode(2800.0, 4000, 1000000L);
        NodeState cloud = cloudNode(44800.0, 40000, 1000000L);

        List<ModuleRequest> reqs = new ArrayList<>();
        for (int j = 0; j < 6; j++) reqs.add(req(0, j, 700.0, 10, 1000L));

        ModulePlacementLBMP solver = new ModulePlacementLBMP(Arrays.asList(d0, d1, proxy, cloud), cloud, reqs);

        for (int j = 0; j < 4; j++) {
            assertEquals("d-0", solver.getAnalyzerToDeviceMap().get("Sensor_Analyzer_0_" + j), "Modules 0-3 consolidate on d-0");
        }
        for (int j = 4; j < 6; j++) {
            assertEquals("d-1", solver.getAnalyzerToDeviceMap().get("Sensor_Analyzer_0_" + j), "Modules 4-5 spill to d-1");
        }
        assertEquals(0.0, d0.available.mips, 1e-9, "d-0 MIPS exhausted");
        assertEquals(3960, d0.available.ramMb, "d-0 RAM decremented by 40");
        assertEquals(996000L, d0.available.bwUnits, "d-0 BW decremented by 4000");
        assertEquals(1400.0, d1.available.mips, 1e-9, "d-1 MIPS remaining");
        assertEquals(2800.0, proxy.available.mips, 1e-9, "proxy untouched");
        assertEquals(44800.0, cloud.available.mips, 1e-9, "cloud untouched");
    }

    // -------------------------------------------------------------------------
    // T06: low = 0 Boundary Reset Verification
    // -------------------------------------------------------------------------
    private static void testT06_LowBoundaryReset() {
        NodeState d0 = gwNode(0, 2800.0, 4000, 1000000L);
        NodeState d1 = gwNode(1, 2800.0, 4000, 1000000L);
        NodeState proxy = proxyNode(2800.0, 4000, 1000000L);
        NodeState cloud = cloudNode(44800.0, 40000, 1000000L);

        List<ModuleRequest> reqs = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 6; j++) reqs.add(req(i, j, 700.0, 10, 1000L));
        }

        ModulePlacementLBMP solver = new ModulePlacementLBMP(Arrays.asList(d0, d1, proxy, cloud), cloud, reqs);

        assertEquals(12, solver.getTotalAnalyzerFog(), "All 12 modules must pack onto 3 Fog nodes");
        assertEquals(0, solver.getTotalAnalyzerCloud(), "Zero Cloud placements when Fog has 12 slots");
        assertEquals(12, solver.getBinarySearchCount(), "All 12 steps use binary search");
        assertEquals(0, solver.getLinearFallbackCount(), "Zero linear fallbacks");
        assertEquals(0.0, d0.available.mips, 1e-9, "d-0 full");
        assertEquals(0.0, d1.available.mips, 1e-9, "d-1 full");
        assertEquals(0.0, proxy.available.mips, 1e-9, "proxy full");
    }

    // -------------------------------------------------------------------------
    // T07: Cloud Selected by Normal Comparison (Full iFogSim Objects)
    // -------------------------------------------------------------------------
    private static void testT07_CloudNormalSelection() {
        CloudSim.init(1, Calendar.getInstance(), false);
        try {
            FogBroker broker = new FogBroker("broker_t07");
            HealthcareTopologyFactory.TopologyContainer tc =
                    HealthcareTopologyFactory.createTopology(broker.getId(), 2, 8, 5.0);
            List<Application> apps = createSymmetricApps(broker.getId(), 2, 8);

            ModulePlacementLBMP solver = new ModulePlacementLBMP(tc.fogDevices, apps);

            assertEquals(12, solver.getTotalAnalyzerFog(), "12 analyzers on Fog (d-0:4, d-1:4, proxy:4)");
            assertEquals(4, solver.getCloudSelectedNormalCount(), "4 analyzers on Cloud via normal search");
            assertEquals(0, solver.getCloudFallbackCount(), "Zero unconditional Cloud fallbacks");
            assertEquals(0.0, solver.getCloudFallbackDemandMips(), 1e-9, "Zero fallback demand MIPS");

            NodeState cloud = solver.getCloudState();
            assertEquals(42000.0, cloud.available.mips, 1e-9, "Cloud remaining MIPS = 44800 - 4*700");
            // Fixed-module accounting convention (D-3.4-07): 16 Cloud_Storage + 4 Cloud Analyzers = 20 modules
            assertEquals(39800, cloud.available.ramMb, "Cloud remaining RAM = 40000 - 16*10 - 4*10");
            assertEquals(980000L, cloud.available.bwUnits, "Cloud remaining BW = 1000000 - 16*1000 - 4*1000");

            assertEquals(48, solver.getVmInstantiationSuccessCount(), "All 3*16=48 VMs actually instantiated");
            assertEquals(0, solver.getVmInstantiationFailureCount(), "Zero VM instantiation failures");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // -------------------------------------------------------------------------
    // T08: Cloud Fallback (Explicit cloudState, Cumulative Demand & VM Failure Separation)
    // -------------------------------------------------------------------------
    private static void testT08_CloudFallbackAndVmFailure() {
        // Part A: Synthetic test where cloudState sorts BEFORE d-0 (cloud NOT at nodes[size - 1]!)
        NodeState cloudSmall = cloudNode(500.0, 40000, 1000000L);
        NodeState d0Small = gwNode(0, 600.0, 4000, 1000000L); // 600 > 500 -> d-0 is at nodes[size - 1]!
        List<ModuleRequest> reqs = Arrays.asList(
                req(0, 0, 700.0, 10, 1000L),
                req(0, 1, 700.0, 10, 1000L)
        );

        ModulePlacementLBMP synth = new ModulePlacementLBMP(Arrays.asList(d0Small, cloudSmall), cloudSmall, reqs);

        assertEquals("cloud", synth.getAnalyzerToDeviceMap().get("Sensor_Analyzer_0_0"), "Fallback must use explicit cloudState, not d-0");
        assertEquals("cloud", synth.getAnalyzerToDeviceMap().get("Sensor_Analyzer_0_1"), "Second fallback must use explicit cloudState");
        assertEquals(0, synth.getCloudSelectedNormalCount(), "Zero normal Cloud selections");
        assertEquals(2, synth.getCloudFallbackCount(), "Two unconditional Cloud fallbacks");
        assertEquals(1400.0, synth.getCloudFallbackDemandMips(), 1e-9, "Cumulative fallback demand MIPS = 2 * 700");
        assertEquals(20, synth.getCloudFallbackDemandRam(), "Cumulative fallback demand RAM = 2 * 10");
        assertEquals(2000L, synth.getCloudFallbackDemandBw(), "Cumulative fallback demand BW = 2 * 1000");
        assertEquals(500.0, cloudSmall.available.mips, 1e-9, "cloudState MIPS must NOT be decremented below zero on fallback");
        assertEquals(2, synth.getFallbackRecords().size(), "Must record 2 individual FallbackRecords");
        FallbackRecord r0 = synth.getFallbackRecords().get(0);
        assertEquals(200.0, r0.unmetDeficitMips, 1e-9, "Individual unmet MIPS deficit = 700 - 500 = 200");
        assertEquals(0, r0.unmetDeficitRam, "Individual unmet RAM deficit = 0");
        assertEquals(0L, r0.unmetDeficitBw, "Individual unmet BW deficit = 0");

        // Part B: Full iFogSim VM instantiation failure separation (synthetic Cloud with only 5 MB RAM)
        CloudSim.init(1, Calendar.getInstance(), false);
        try {
            FogBroker broker = new FogBroker("broker_t08b");
            FogDevice tinyCloud = createCustomFogDevice("cloud", 500, 5, 100, 10000, 0, 0.01);
            tinyCloud.setParentId(-1);
            FogDevice tinyProxy = createCustomFogDevice("proxy-server", 500, 4000, 10000, 10000, 1, 0.0);
            tinyProxy.setParentId(tinyCloud.getId());
            FogDevice tinyGw = createCustomFogDevice("d-0", 500, 4000, 10000, 10000, 2, 0.0);
            tinyGw.setParentId(tinyProxy.getId());
            FogDevice mobile = createCustomFogDevice("m-0-0", 1000, 1000, 10000, 270, 3, 0.0);
            mobile.setParentId(tinyGw.getId());

            List<FogDevice> devices = Arrays.asList(tinyCloud, tinyProxy, tinyGw, mobile);
            Application app = HealthcareBSNApplication.createApplication("app_0_0", broker.getId(), "0_0");
            app.setUserId(broker.getId());

            ModulePlacementLBMP solver = new ModulePlacementLBMP(devices, Collections.singletonList(app));

            assertEquals(1, solver.getCloudFallbackCount(), "Analytical fallback count = 1");
            assertEquals(0, solver.getCloudSelectedNormalCount(), "Normal Cloud count = 0");
            assertEquals(700.0, solver.getCloudFallbackDemandMips(), 1e-9, "Cumulative fallback demand MIPS = 700");
            assertEquals(10, solver.getCloudFallbackDemandRam(), "Cumulative fallback demand RAM = 10");
            assertEquals(1000L, solver.getCloudFallbackDemandBw(), "Cumulative fallback demand BW = 1000");
            assertTrue(solver.getCloudState().available.ramMb >= 0, "cloudState RAM must stay non-negative");

            // HostEntity.guestCreate rejects both Sensor_Analyzer_0_0 (10 MB) and Cloud_Storage_0_0 (10 MB) on 5 MB Cloud!
            assertEquals(1, solver.getVmInstantiationSuccessCount(), "Only Interface_0_0 on m-0-0 instantiated");
            assertEquals(2, solver.getVmInstantiationFailureCount(), "Both Cloud modules failed CloudSim VM creation");
            boolean sawFallbackVmFail = false;
            for (VmInstantiationFailure f : solver.getVmInstantiationFailures()) {
                if (f.moduleName.equals("Sensor_Analyzer_0_0") && f.wasCloudFallback) {
                    sawFallbackVmFail = true;
                }
            }
            assertTrue(sawFallbackVmFail, "Fallback module VM instantiation failure must be tracked explicitly");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    // -------------------------------------------------------------------------
    // T09: Deterministic Tie Handling (5 Shuffled Permutations)
    // -------------------------------------------------------------------------
    private static void testT09_DeterministicTieHandling() {
        Map<String, String> baselineMap = null;
        int[] workload = new int[] { 2, 6 };

        for (int perm = 0; perm < 5; perm++) {
            CloudSim.init(1, Calendar.getInstance(), false);
            try {
                FogBroker broker = new FogBroker("broker_t09_" + perm);
                AsymmetricTopologyFactory.TopologyContainer tc =
                        AsymmetricTopologyFactory.createAsymmetricTopology(broker.getId(), workload, 5.0);
                List<Application> apps = createAsymmetricApps(broker.getId(), workload);

                Random rng = new Random(100L + perm);
                List<FogDevice> shuffledDevices = new ArrayList<>(tc.fogDevices);
                List<Application> shuffledApps = new ArrayList<>(apps);
                Collections.shuffle(shuffledDevices, rng);
                Collections.shuffle(shuffledApps, rng);

                ModulePlacementLBMP solver = new ModulePlacementLBMP(shuffledDevices, shuffledApps);
                Map<String, String> currentMap = solver.getAnalyzerToDeviceMap();

                if (baselineMap == null) {
                    baselineMap = currentMap;
                    // Pure LBMP (zero affinity): d-0 consolidates first 4 sorted modules: app_0_0, 0_1, 1_0, 1_1
                    assertEquals("d-0", currentMap.get("Sensor_Analyzer_0_0"), "app_0_0 on d-0");
                    assertEquals("d-0", currentMap.get("Sensor_Analyzer_0_1"), "app_0_1 on d-0");
                    assertEquals("d-0", currentMap.get("Sensor_Analyzer_1_0"), "app_1_0 on d-0 (pure capacity packing, no affinity)");
                    assertEquals("d-0", currentMap.get("Sensor_Analyzer_1_1"), "app_1_1 on d-0 (pure capacity packing, no affinity)");
                    assertEquals("d-1", currentMap.get("Sensor_Analyzer_1_2"), "app_1_2 on d-1");
                    assertEquals("d-1", currentMap.get("Sensor_Analyzer_1_5"), "app_1_5 on d-1");
                } else {
                    assertTrue(baselineMap.equals(currentMap),
                            "Permutation " + perm + " produced non-deterministic mapping: " + currentMap);
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    // -------------------------------------------------------------------------
    // T10: Monotonicity Guard & Linear-Scan Fallback
    // -------------------------------------------------------------------------
    private static void testT10_MonotonicityGuardAndLinearFallback() {
        NodeState n0 = gwNode(0, 1000.0, 4000, 1000000L); // Eligible: TRUE
        NodeState n1 = gwNode(1, 2000.0, 5, 1000000L);    // Ineligible RAM: FALSE
        NodeState n2 = cloudNode(3000.0, 5, 1000000L);    // Ineligible RAM: FALSE
        ModuleRequest m = req(0, 0, 500.0, 10, 1000L);

        List<NodeState> nodes = Arrays.asList(n0, n1, n2);
        assertTrue(!ModulePlacementLBMP.isEligibilityMonotonic(nodes, m), "Predicate [TRUE, FALSE, FALSE] must be flagged non-monotonic");

        ModulePlacementLBMP solver = new ModulePlacementLBMP(nodes, n2, Collections.singletonList(m));

        assertEquals(0, solver.getBinarySearchCount(), "Binary search must be bypassed on non-monotonicity");
        assertEquals(1, solver.getLinearFallbackCount(), "Linear scan fallback must trigger once");
        assertEquals("d-0", solver.getAnalyzerToDeviceMap().get("Sensor_Analyzer_0_0"), "Linear fallback must find n0 instead of falsely falling back to Cloud");
        assertEquals(0, solver.getCloudFallbackCount(), "No false Cloud fallback");
    }

    // -------------------------------------------------------------------------
    // T11: Exact 3N Module & VM Accounting (N = 4, 8, 12, 16, 32)
    // -------------------------------------------------------------------------
    private static void testT11_Exact3NAccounting() {
        int[][] configs = new int[][] {
                { 2, 2, 4, 0 },   // N=4  -> 4 Fog, 0 Cloud
                { 2, 4, 8, 0 },   // N=8  -> 8 Fog, 0 Cloud
                { 2, 6, 12, 0 },  // N=12 -> 12 Fog, 0 Cloud
                { 2, 8, 12, 4 },  // N=16 -> 12 Fog, 4 Cloud
                { 4, 8, 20, 12 }  // N=32 -> 20 Fog, 12 Cloud
        };

        for (int[] cfg : configs) {
            int gws = cfg[0], mobs = cfg[1], expFog = cfg[2], expCloud = cfg[3];
            int n = gws * mobs;

            CloudSim.init(1, Calendar.getInstance(), false);
            try {
                FogBroker broker = new FogBroker("broker_t11_" + n);
                HealthcareTopologyFactory.TopologyContainer tc =
                        HealthcareTopologyFactory.createTopology(broker.getId(), gws, mobs, 5.0);
                List<Application> apps = createSymmetricApps(broker.getId(), gws, mobs);

                ModulePlacementLBMP solver = new ModulePlacementLBMP(tc.fogDevices, apps);

                assertEquals(n, solver.getTotalAnalyzers(), "Total analyzers == N (" + n + ")");
                assertEquals(expFog, solver.getTotalAnalyzerFog(), "Fog analyzers for N=" + n);
                assertEquals(expCloud, solver.getCloudSelectedNormalCount(), "Normal Cloud analyzers for N=" + n);
                assertEquals(0, solver.getCloudFallbackCount(), "Zero fallback Cloud placements for N=" + n);
                assertEquals(3 * n, solver.getPlannedSystemModules(), "Planned 3N invariant for N=" + n);
                assertEquals(3 * n, solver.getVmInstantiationSuccessCount(), "Actual CloudSim VM 3N invariant for N=" + n);
                assertEquals(0, solver.getVmInstantiationFailureCount(), "Zero VM instantiation failures for N=" + n);
                assertEquals(n, solver.getBinarySearchCount(), "100% monotonic binary search for N=" + n);
                assertEquals(0, solver.getLinearFallbackCount(), "Zero linear fallbacks for N=" + n);
                assertEquals(0.0, solver.getCloudFallbackDemandMips(), 1e-9, "Zero fallback demand MIPS for N=" + n);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private static List<Application> createSymmetricApps(int brokerId, int gws, int mobsPerGw) {
        List<Application> apps = new ArrayList<>();
        for (int i = 0; i < gws; i++) {
            for (int j = 0; j < mobsPerGw; j++) {
                String sfx = i + "_" + j;
                Application app = HealthcareBSNApplication.createApplication("app_" + sfx, brokerId, sfx);
                app.setUserId(brokerId);
                apps.add(app);
            }
        }
        return apps;
    }

    private static List<Application> createAsymmetricApps(int brokerId, int[] mobsPerGw) {
        List<Application> apps = new ArrayList<>();
        for (int i = 0; i < mobsPerGw.length; i++) {
            for (int j = 0; j < mobsPerGw[i]; j++) {
                String sfx = i + "_" + j;
                Application app = HealthcareBSNApplication.createApplication("app_" + sfx, brokerId, sfx);
                app.setUserId(brokerId);
                apps.add(app);
            }
        }
        return apps;
    }

    private static FogDevice createCustomFogDevice(String name, long mips, int ram,
                                                   long upBw, long downBw, int level, double ratePerMips) throws Exception {
        List<Pe> peList = new ArrayList<>();
        peList.add(new Pe(0, new PeProvisionerOverbooking(mips)));
        PowerHost host = new PowerHost(
                FogUtils.generateEntityId(),
                new RamProvisionerSimple(ram),
                new BwProvisionerOverbooking(1000000),
                10000000,
                peList,
                new StreamOperatorScheduler(peList),
                new FogLinearPowerModel(107.339, 83.4333)
        );
        List<Host> hostList = new ArrayList<>();
        hostList.add(host);
        FogDeviceCharacteristics characteristics = new FogDeviceCharacteristics(
                "x86", "Linux", "Xen", host, 10.0, 3.0, 0.05, 0.001, 0.0);
        FogDevice dev = new FogDevice(name, characteristics,
                new AppModuleAllocationPolicy(hostList), new LinkedList<Storage>(),
                10, upBw, downBw, 0, ratePerMips);
        dev.setLevel(level);
        return dev;
    }
}
